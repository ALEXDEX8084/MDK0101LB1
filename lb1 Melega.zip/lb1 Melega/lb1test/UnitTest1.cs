﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using LB1Library;

namespace lb1test
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestQMethod1()
        {
            double x = 1.825;
            double y = 18.225;
            double z = -3.298;
            double excepted = 57742.0257793583;
            Class1 c = new Class1();
            double actual = c.Q(x, y, z);
            Assert.AreEqual(excepted, actual);
        }
        [TestMethod]
        public void TestQMethod2()
        {
            double x = 0;
            double y = 0;
            double z = 0;
            double excepted = 0;
            Class1 c = new Class1();
            double actual = c.Q(x, y, z);
            Assert.AreEqual(excepted, actual);
        }
        [TestMethod]
        public void TestQMethod3()
        {
            double x = 1.825;
            double y = 0;
            double z = 0;
            double excepted = 1;
            Class1 c = new Class1();
            double actual = c.Q(x, y, z);
            Assert.AreEqual(excepted, actual);
        }
        [TestMethod]
        public void TestQMethod4()
        {
            double x = -10;
            double y = 0;
            double z = 0;
            double excepted = 1;
            Class1 c = new Class1();
            double actual = c.Q(x, y, z);
            Assert.AreEqual(excepted, actual);
        }
        [TestMethod]
        public void TestQMethod5()
        {
            double x = -10;
            double y = -10;
            double z = 0;
            double excepted = 0.9999999999;
            Class1 c = new Class1();
            double actual = c.Q(x, y, z);
            Assert.AreEqual(excepted, actual);
        }
        [TestMethod]
        public void TestNMethod1()
        {
            double x = 1.825;
            double y = 18.225;
            double z = -3.298;
            double excepted = 1.11938064898503;
            Class1 c = new Class1();
            double actual = c.N(x, y, z);
            Assert.AreEqual(excepted, actual);
        }
        [TestMethod]
        public void TestNMethod2()
        {
            double x = 0;
            double y = 0;
            double z = 0;
            double excepted = 0;
            Class1 c = new Class1();
            double actual = c.N(x, y, z);
            Assert.AreEqual(excepted, actual);
        }
        [TestMethod]
        public void TestNMethod3()
        {
            double x = 1.825;
            double y = 0;
            double z = 0;
            double excepted = 0;
            Class1 c = new Class1();
            double actual = c.N(x, y, z);
            Assert.AreEqual(excepted, actual);
        }
        [TestMethod]
        public void TestNMethod4()
        {
            double x = -10;
            double y = 0;
            double z = 0;
            double excepted = 0;
            Class1 c = new Class1();
            double actual = c.N(x, y, z);
            Assert.AreEqual(excepted, actual);
        }
        [TestMethod]
        public void TestNMethod5()
        {
            double x = -10;
            double y = -10;
            double z = 0;
            double excepted = 0.9999999999;
            Class1 c = new Class1();
            double actual = c.N(x, y, z);
            Assert.AreEqual(excepted, actual);
        }
    }
}
