﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LB1Library
{
    public class Class1
    {
        public double Q(double x, double y, double z)
        {
            return Math.Abs(Math.Pow(x, y) - Math.Sqrt(y/x));
        }
        public double N(double x, double y, double z)
        {
            return (y-x)*(y-z/(y-x))/(1+Math.Pow((y-x),2));
        }

    }
}
